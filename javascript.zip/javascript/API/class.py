class Student():
    percent_rise = 1.05
    def __init__(self,first,last,marks):
        self.first = first
        self.last = last
        self.marks = marks
        self.email = first +"."+last+"@school.com"

    def fullname(self):
        return "{} {}".format(self.first,self.last)

    def marks_rise(self):
        self.marks = int(self.marks * 1.05)
        return self.marks

class Dumb(Student):
    def __init__(self,first,last,marks,prog_lang):
        super().__init__(first,last,marks)
        self.prog_lang = prog_lang



std_1 = Dumb("lubwama","Isaac",50,"python")
print(std_1.prog_lang)
std_2 = Student("Kigozi","Ivan",90)

print(std_1.marks_rise())
print(std_2.marks_rise())
print(std_1.__dict__)


