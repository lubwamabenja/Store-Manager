from abc import ABC,abstractmethod

class Employee(ABC):

    @abstractmethod

    def calculate_salary(self,sal):

        pass

class Developer(Employee):

    def calculate_salary(self,sal):

        final_salary = sal * 1.10

        return final_salary


std_1 = Developer()

print(std_1.calculate_salary(10000))