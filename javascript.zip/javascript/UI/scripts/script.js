/* Validating user credentials*/
function validate(){
    var username = document.getElementById("uname").value;
    var password = document.getElementById("passw").value;
    if(username == "lubwama" && password =="lubwama"){
        alert("Login successfull");
        window.location = "UI/html/home.html";
        displayLinks();
        return false;
        
    }
    else if(username == "password" && password =="password"){
        alert("Login successfull");
        window.location = "/html/cart.html";
        return false;

    }
    else{
        alert("Username && password combination is wrong");
        return false;
    }

}
/*display all links*/
function displayLinks(){
    document.getElementById('pdt_link').style.display = 'block';
    document.getElementById('pdt_link1').style.display = 'block';


}
/*side menu*/
function openSlideMenu(){
    document.getElementById('side-menu').style.width = '250px';
    document.getElementById('header').style.marginLeft = '250px';
}

function closeSlideMenu(){
    document.getElementById('side-menu').style.width = '0';
    document.getElementById('header').style.marginLeft = '0';
}


/* Addition of products */
function resetform () {
    var clearproduct = document.getElementById('product');
    clearproduct.value = "";
    var clearquantity = document.getElementById('quantity');
    clearquantity.value = "";
    var clearprice = document.getElementById('price');
    clearprice.value = "";
    }
var i = 0;
var categoryArray = new Array();
var productArray = new Array();
var quantityArray = new Array();
var priceArray = new Array();



function blankForm () {
    var errormessage = "";
    if (document.getElementById('product').value == "") {
        errormessage +="Please enter product. \n";
        document.getElementById('product').style.borderColor = "red";
        }
    if (document.getElementById('quantity').value == "") {
        errormessage +="Please enter quantity. \n";
        document.getElementById('quantity').style.borderColor = "red";
        } 
    if (document.getElementById('price').value == "") {
        errormessage +="Please enter price. \n";
        document.getElementById('price').style.borderColor = "red";
        }
    if (errormessage != "") {

        alert(errormessage);
            return false;
        }
    else {

        alert('Data entered successfully!');
        var e = document.getElementById("opt_id");
        categoryArray[i] = e.options[e.selectedIndex].text;
        productArray[i] = document.getElementById('product').value;
        quantityArray[i] = document.getElementById('quantity').value;
        priceArray[i] = document.getElementById('price').value;

        i++;
        document.getElementById('output').innerHTML ='';
        for(g=0;g<productArray.length;g++){
            document.getElementById('output').innerHTML = document.getElementById('output').innerHTML +"  Category: "+ categoryArray[g]+ "<br>";
            document.getElementById('output').innerHTML = document.getElementById('output').innerHTML +"  Product:  "+ productArray[g]+ "  <br>";
            document.getElementById('output').innerHTML = document.getElementById('output').innerHTML +"  Quantity: "+ quantityArray[g]+ " <br>";
            document.getElementById('output').innerHTML = document.getElementById('output').innerHTML +"  Unitcost: "+ priceArray[g]+" <br>";
            var totalcost = quantityArray[g] * priceArray[g];
            document.getElementById('output').innerHTML = document.getElementById('output').innerHTML +"  TotalCost: "+ totalcost+" <br>";
                        }
        
        var productsub = document.getElementById('product');
        productsub.value = "";
        var quantitysub = document.getElementById('quantity');
        quantitysub.value= "";
        var pricesub= document.getElementById('price');
        pricesub.value= "";
        var opt = document.getElementById('opt_id');
        var catsub =opt.options[opt.selectedIndex].text;
        catsub.value = "";

        }
}


