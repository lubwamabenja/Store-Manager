class Motorcycle {
    String color;
    String make;
    boolean engineState;


    void Startengine() {
        if (engineState == true)
            System.out.println("The engine is already on");
        else {
            engineState = true;
            System.out.println("The engine is now on");
        }
    
    }
    void Showatts() {
        System.out.println("This motorcycle is a "
            + color + " " + make);
        if (engineState == true)
            System.out.println("The engine is on");
        else {
            System.out.println("The engine is off");
        }
    }

    public static void main (String args[]){
        Motorcycle m = new Motorcycle();
        m.color = "yellow";
        m.make = "Yamaha RZ5340";
        System.out.println("calling Showatts......");
        m.Showatts();
        System.out.println("...................");
        System.out.println("calling Startengine.....");
        m.Startengine();
        System.out.println(".................");
        System.out.println("calling Showatts......");
        m.Showatts();
        System.out.println("...................");
        System.out.println("calling Startengine.....");
        m.Startengine();
        System.out.println(".................");

    }

}